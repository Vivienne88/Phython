from distutils.core import setup

setup(
    name = "PythonTestModule",
    version = "1.1.0",
    py_modules = ["print_data"],
    author = "nini",
    author_email = "nini@gmail.com",
    url = "http://www.naver.com",
    description = "Test Module",
    )